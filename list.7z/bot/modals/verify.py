import aiosqlite, datetime, discord, asyncio
from discord.ext import commands

async def setup_vouch(ctx):
    pass