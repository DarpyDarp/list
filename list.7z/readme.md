# Skyblock Value Bot

- This bot is fairly simple, all you need to do is insert a bot token into the config.json file and type python3 start.py

# Documentation:

**The configuration file has scale factor values, not all are scale factor so pay attention to the ones that have different values.**
**If you dislike the pricing in one aspect, increase/lower the scale factor until you agree with the value**
