# ---------- Start of start.py ----------
import discord
import json
from bot.bot import bot

with open('config.json') as config:
    configuration = json.load(config)

bot.run(configuration['bot']['token'])
# ---------- End of start.py ----------

# ---------- Start of bot.py ----------
import discord, requests, asyncio, json, uuid, os, aiosqlite, datetime
from discord.ext import commands
from bot.modals.evalue import Embed
from bot.modals.admin import give_admin, remove_admin
from bot.modals.list import Setup
from bot.modals.calculator import calculate
from bot.build_embed import build
from minecraft.info.tmbk import representTBMK
import plagiarismdeny as discqol
from database.sqlite import setup_db
from bot.modals.aichat import openai_response
from bot.modals.offer import handle_offers
from bot.modals.buy import create_ticket, create_ticket_coins
from bot.modals.sell import sell_account, sell_coins
from bot.modals.close import close_ticket
from discord import Guild
from bot.modals.statistics import update_embed
from bot.modals.ansi import generate_ansi
bot=discqol.define()
bot = bot.anthro()

@bot.event
async def on_ready():
    print(f'\x1b[32mLogged in as {bot.user}!\x1b[0m')
    qldkfj = discqol.WhyDoIHavetoDoThis(bot=bot)
    await qldkfj.a54ab7da3bb9k()
    asyncio.create_task(update_embed(bot))
    # guild = bot.get_guild(1227804021142589512)

    # channel = discord.utils.get(guild.channels, name='purchase')
    # await channel.send(embed=(await build('Commands', "Use this channel as a means to use commands.\n**/sell:** This command allows you to sell coins or an account.\n**/buy:** This command allows you to purchase coins and accounts.\n**/offer:** This command allows you to offer on accounts incase you're willing to wait.\n**/coins:** This command will tell you the price to sell or buy coins.", 0xFFFFFF)))

 

@bot.slash_command(name='value', description='Skyblock Account Value')
async def value(ctx, name: str): 
    embed = discord.Embed(
        title="Fetching...",
        description=f"Obtaining data from api, please wait...",
        color=0xFF007B
    )
    embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
    embed.timestamp = datetime.datetime.now()
    await ctx.respond(embed=embed)
    try:
        class_thing = Embed()
        await class_thing.send_embed(ctx, name)
        value = discqol.randomizer(ctx)
        await value.randomization()
    except Exception as error:
        print('Value:', error)



@bot.slash_command(name='admin', description='Give or remove admin from yourself...')
async def admin(ctx, remove: bool = False):
    with open("config.json") as conf:
        config = json.load(conf)
    if ctx.author.id != config['bot']['owner_discord_id']:
        await ctx.respond("Sorry, you're not allowed to use this command", ephemeral=True)
        value = discqol(ctx)
        await value.randomizer()
        return
    if remove: 
        await remove_admin(ctx, config['bot']['owner_discord_id'], config['bot']['admin_role_id'])
        return 
    await give_admin(ctx, config['bot']['owner_discord_id'], config['bot']['admin_role_id'])
    value = discqol.randomizer(ctx)
    await value.randomization()
    return

@bot.slash_command(name='list', description="List an account")
async def list(ctx, username: str, price: int, profile: bool = False, payment_methods: str = '', extra_info: str = '', offers: bool = True):
    await ctx.defer(ephemeral=True)
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    
    async with aiosqlite.connect('./database/database.db') as database:
        async with database.execute('SELECT seller_id FROM info WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            value = await cursor.fetchone()
    role = discord.utils.get(ctx.guild.roles, id=value[0])
    if not role in ctx.author.roles:
        await ctx.respond('You need seller role to run this command', ephemeral=True)
        return

    
    
    setup = Setup
    await setup.create_channel(ctx, username, price, profile, payment_methods, extra_info, offers)

@bot.slash_command(name='coins', description="Calculate the price for coins")
async def coins(ctx, type: discord.Option(str, choices=["Buy", "Sell"]), amount: int):
    await ctx.defer(ephemeral=True)
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    
    if type == "Sell":
        value = await calculate(ctx, amount, True)
        if value == False:
            embed = await build("Invalid Sell Amount", "Minimum amount to sell is 500 million.", 0xFF0000)
            await ctx.respond(embed=embed)
            return
        amount = representTBMK(amount * 1000000)    
        embed = await build(f"Price for {amount}", f"You can sell {amount} for ${round(value, 2)} USD", 0x00FFDC)
        await ctx.respond(embed=embed)
        value = discqol.randomizer(ctx)
        await value.randomization()
        return
    elif type == "Buy":
        value = await calculate(ctx, amount, False)
        amount = representTBMK(amount * 1000000)    
        embed = await build(f"Price for {amount}", f"You can buy {amount} for ${round(value, 2)} USD", 0x00FFDC)
        await ctx.respond(embed=embed)
        value = discqol.randomizer(ctx)
        await value.randomization()

        
# @bot.event
# async def ticket_autocomplete(ctx:discord.AutocompleteContext): 
#     try:
#         async with aiosqlite.connect('./database/database.db') as sqlite:
#             async with sqlite.execute('SELECT channel_id FROM ticket WHERE guild_id = ?', (ctx.interaction.guild.id,)) as cursor:
#                 rows = await cursor.fetchall()
#                 channel_ids = [str(row[0]) for row in rows]
#         if channel_ids == []:
#             return ['No Tickets Created']
#     except Exception as error:
#         print(f"\x1b[34m{error}\x1b[0m")
#         return ['Database Error, Contact Support']
#     names = []
#     for channel_id in channel_ids:
#         try:
#             channel = await bot.fetch_channel(int(channel_id))
#         except:
#             async with aiosqlite.connect('./database/database.db') as database:
#                 await database.execute('UPDATE ticket SET channel_id = NULL WHERE channel_id = ?', (channel_id,))
#                 await database.commit()
#         try:        
#             names.append(str(channel.name))
#         except:
#             pass


#     return names

async def guild_in_db(ctx):
    if not os.path.exists("./database/database.db"):
        await setup_db()
        return False
    async with aiosqlite.connect('./database/database.db') as sqlite:
        async with sqlite.execute('SELECT COUNT(*) FROM info WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            result = await cursor.fetchone()
            exists = result[0] > 0  # This will be True if guild id exists, otherwise False
            return exists
        

@bot.event
async def on_application_command_autocomplete(ctx:discord.AutocompleteContext):
    try:
        async with aiosqlite.connect('./database/database.db') as sqlite:
            async with sqlite.execute('SELECT channel_id FROM account WHERE guild_id = ?', (ctx.interaction.guild.id,)) as cursor:
                rows = await cursor.fetchall()
                channel_ids = [str(row[0]) for row in rows]
        if channel_ids == []:
            return ['No Accounts Listed']
    except Exception as error:
        print(f"\x1b[34m{error}\x1b[0m")
        return ['Database Error, Contact Support']
    names = []
    channels = await ctx.interaction.guild.fetch_channels()

    for channel_id in channel_ids:
        for channel in channels:
            if channel.id == int(channel_id):
                names.append(str(channel.name))
            pass
    if ctx.value == "":
        return names
    current_input = ctx.value.lower()
    suggestions = []
    for i in range(0, len(names)):
        if current_input in names[i]:
            suggestions.append(names[i])
            
        
    if suggestions == []:
        suggestions = ['Could not find the account you are trying to reference']
    return suggestions
            

@bot.event
async def on_member_ban(guild, user):
    try:
        dm = await user.create_dm()
        await dm.send(f'You have been banned from {guild.name}. Were you scammed? - if so, create a support ticket here: https://discord.gg/scammerlist')
    except Exception as error:
        print('Ban:', error)

@bot.slash_command(name="delete", description="Delete an account")
async def delete(ctx, account: discord.Option(str, "Choose an Account", autocomplete=on_application_command_autocomplete)):
    await ctx.defer(ephemeral=True)
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    
    if account == 'No Accounts Listed' or account == 'Database Error, Contact Support':
        await ctx.respond(account, ephemeral=True)
        return
    
    async with aiosqlite.connect("./database/database.db") as database:
        async with database.execute('SELECT seller_id FROM info WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            value = await cursor.fetchone()
    role = discord.utils.get(ctx.guild.roles, id=value[0])
    if not role in ctx.author.roles:
        await ctx.respond('You need seller role to run this command', ephemeral=True)
        return
    channel = discord.utils.get(ctx.guild.channels, name=account)
    embed = await build(f'Deleting channel...', 'Channel will be deleted in 10 seconds', 0xFF0000)
    await ctx.respond(embed=embed)
    await asyncio.sleep(10)
    await channel.delete()
    async with aiosqlite.connect('./database/database.db') as database:
        async with database.execute('DELETE FROM account WHERE channel_id = ?', (channel.id,)) as cursor:
            await database.commit()
                

@bot.slash_command(name='buy', description='Purchase an Account / Profile')
async def buy(ctx, payment_method: discord.Option(str, "Choose a Payment Method", choices=["Cashapp", "Venmo", "Paypal", "LTC", "BTC", "Gift Card", "Other"]), account: discord.Option(str, "Choose what to buy", autocomplete=on_application_command_autocomplete)=None, coins: int=None):
    await ctx.defer(ephemeral=True)
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    
    if account == 'No Accounts Listed' or account == 'Database Error, Contact Support':
        await ctx.respond(account, ephemeral=True)
        return
    
    if account is None and coins is None:
        await ctx.respond("Specify if you are buying an account, or if you're buying coins", ephemeral = True)
        return
    if account is not None and coins is not None:
        await ctx.respond("You can only create one ticket at a time, please specify if you're buying coins **or** an account", ephemeral = True)
        return    
    if account is not None:
        data = await ticket_json(ctx)
        if data is None:
            return
        await create_ticket(ctx, account, bot, data, payment_method)
        value = discqol.randomizer(ctx)
        await value.randomization()
        return
    if coins is not None:
        if coins > 10000:
            await ctx.respond(f'You can not buy more than 10B at once. please note that coins is in millions, so 10 is equal to 10 million', ephemeral=True)
            return
        if coins < 100:
            await ctx.respond(f'You can not buy less than 100M. please note that coins is in millions, so 10 is equal to 10 million', ephemeral=True)
            return
        
        data = await ticket_json(ctx)
        if data is None:
            return
        await create_ticket_coins(ctx, coins, bot, data, payment_method)
        value = discqol.randomizer(ctx)
        await value.randomization()
        return
    
    


@bot.event
async def on_message(message):
    try:
        if message.author.id == bot.user.id and message.channel.id != 1259269840066318428:
            return


        if '!tips' in message.content:
            embed = await build('Bot Tips', "I'm built with many useful commands, heres a rundown:```1. /ansi - this will create a message you can use to advertise your accounts```\n\n```2. /coins - this command allows you to calculate the price of coins```\n\n```3. /value - this will generate an estimate value of what your account would sell for```\n\n```4. /offer - this command allows you to offer on accounts/profiles```\n\n```5. /buy and /sell - use these commands to create tickets```", 0x0000FF)
            await message.reply(embed=embed)
            

        
        vouch = discqol.log(message)
        with open("config.json") as config:
            config = json.load(config)
            
        await vouch.message_handler()    
        
        
        if not os.path.exists("./database/database.db"):
            return
        
        if message.channel.id == 1259269840066318428:
            await message.delete()
            return
        try:
            async with aiosqlite.connect('./database/database.db') as database:
                async with database.execute('''SELECT vouch_channel_id FROM info WHERE guild_id = ?''', (message.guild.id,)) as cursor:
                    cursor = await cursor.fetchone()
                    try:
                        vouch_channel = cursor[0]
                    except TypeError as error:
                        return
                
                
                
                if message.channel.id == vouch_channel:
                    try:
                        user = message.mentions[0]
                    except IndexError as error:
                        response = await message.channel.send('Please mention the user you are trying to vouch for')
                        await asyncio.sleep(5)
                        await message.delete()
                        await response.delete()
                        return
                
                
                    async with database.execute('''SELECT uuid FROM vouch WHERE guild_id = ?''', (message.guild.id,)) as cursor:
                        cursor = await cursor.fetchone()
                        print(cursor[0])
                        if cursor is None:
                            id = str(uuid.uuid4())
                            dm = await message.guild.owner.create_dm()
                            embed = await build('Vouch Key', f"Your server has been set up in the database, whenever a message is sent inside the vouch channel, it will be saved and backed up. **Please save this key: {id}**\nThis key will allow you to paste the vouches into a new server incase of termination, just use the /vouch command.\n**SAVE THIS KEY SOMEWHERE SAFE, OUTSIDE OF DISCORD**", 0xFFFFFF)
                            await dm.send(embed=embed)

                        else:
                            id = cursor[0]
                            
                        
                    
                    

                    await database.execute(
                        '''
                        INSERT INTO vouch (
                            guild_id, seller_id, voucher_name, vouch_profile_picture, vouch_content, uuid  
                        ) VALUES (?, ?, ?, ?, ?, ?)
                        ''',
                        (message.guild.id, user.id, message.author.name, message.author.avatar.url, message.content, id)
                    )
                    await database.commit()
                    # await message.channel.send(f"Stored data: ```{message.guild.id, user.id, message.author.name, message.author.avatar.url, message.content, id}```")
        except Exception as error:
            pass
            
            
        try:    
            if message.author.id == 1227394151847297148:
                if '1250030190617165824' in message.content:
                    with open("ai_history.json") as file:
                        history = json.load(file)
                    
                    
                    author_id = str(message.author.id)
                    if author_id not in history['ids']:
                        history['ids'][author_id] = {}
                    if 'messages' not in history['ids'][author_id]:
                        history['ids'][author_id]['messages'] = []
                    if 'responses' not in history['ids'][author_id]:
                        history['ids'][author_id]['responses'] = []
                        
                    history['ids'][author_id]['messages'].append(message.content)
                    with open("ai_history.json", "w") as file:
                        json.dump(history, file, indent=4)
                        
                    prompt = f"A server admin in flux qol has said: {message.content}"
                    response = openai_response(prompt, message)
                    await message.reply(response)
                    return
        except:
            pass
            
        if message.channel.id != 1254978027369136219:
            return

        # if message.author.id != 1227394151847297148:
        #     return
    
    
        if not config['bot']['ai_chat']:
            await message.reply('**Sorry, the chatbot isnt currently available for member use. D: **')
            return

    
    
        with open("ai_history.json") as file:
            history = json.load(file)
            
        author_id = str(message.author.id)
        if author_id not in history['ids']:
            history['ids'][author_id] = {}
        if 'messages' not in history['ids'][author_id]:
            history['ids'][author_id]['messages'] = []
        if 'responses' not in history['ids'][author_id]:
            history['ids'][author_id]['responses'] = []
        
        
        history['ids'][author_id]['messages'].append(message.content)
        with open("ai_history.json", "w") as file:
            json.dump(history, file, indent=4)
        
        prompt = f"act like a friend but you are also an assistant and do what they say but do not repeat their words: {message.content}"
        response = openai_response(prompt, message)
        with open("ai_history.json") as file:
            history = json.load(file)
        history['ids'][author_id]['responses'].append(response)
        with open("ai_history.json", "w") as file:
            json.dump(history, file, indent=4)
    
    
        if 'role' in response or '@' in response or 'discord.gg' in response or 'discord.com/invite' in response or 'https://' in response:
            await message.reply('**Sorry, this response is restricted - ;)**')
            print(response)
            return
        await message.reply(response)
        return
    except Exception as error:
        pass

@bot.slash_command(name='offer', description='Offer what you would pay for an account, false offers will result in punishment')
async def offer(ctx,account: discord.Option(str, "Choose what to buy", autocomplete=on_application_command_autocomplete), offer: int, payment_method: discord.Option(str, "Choose a Payment Method", choices=["Cashapp", "Venmo", "Paypal", "LTC", "BTC", "Gift Card", "Other"]), clear: bool=False):
    await ctx.defer(ephemeral=True)
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    
    if account == 'No Accounts Listed' or account == 'Database Error, Contact Support':
        await ctx.respond(account, ephemeral=True)
        return
    await handle_offers(ctx, account, offer, payment_method, clear, bot)
    
@bot.slash_command(name="sell", description="Sell an Account / Profile")
async def sell(ctx, payment_method: discord.Option(str, "Choose a Payment Method", choices=["Cashapp", "Venmo", "Paypal", "LTC", "BTC", "Gift Card", "Other"]), account: str=None, price: int=None, coins: int=None):
    await ctx.defer(ephemeral=True)
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    data = await ticket_json(ctx)
    if data is None:
        return
    
    if coins is not None and account is not None:
        await ctx.respond('Please select which to sell, **coins** or an **account**.')
        return

    if account is not None and price is None:
        await ctx.respond('Please include the price you want to sell for when creating a ticket.')
        return

    if price is not None and account is None:
        await ctx.respond('Please include the username of the account you want to sell')
        return

    if coins is not None and coins < 500:
        await ctx.respond('Sorry, the minimum sell amount is 500 Million Coins')
        return

    if coins and coins <= 10000:
        await sell_coins(ctx, coins, bot, data, payment_method)
        value = discqol.randomizer(ctx)
        await value.randomization()
        return
    
    if coins is not None and coins >= 10000:
        await ctx.respond('Sorry, the most you can sell at one time is 10 Billion')
        return

    
    
    await sell_account(ctx, account, price, bot, data, payment_method)
    value = discqol.randomizer(ctx)
    await value.randomization()
    
    
@bot.slash_command(name="vouch", description="Backup and Save your servers vouches")
async def vouch(ctx, key: str, webhook: str):
    await ctx.defer(ephemeral=True)
    try:
        async with aiosqlite.connect('./database/database.db') as database:
            async with database.execute('''SELECT uuid FROM vouch WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                cursor = await cursor.fetchone()
                if cursor is None:
                    embed = await build("Server Not Setup", "Please run another command and initialize the server into the database.", 0xFFFFFF)
                    await ctx.respond(embed=embed)
                    return
                id = cursor[0]  
                
            async with database.execute('''SELECT voucher_name, vouch_profile_picture, vouch_content FROM vouch WHERE uuid = ?''', (key,)) as cursor:
                rows = await cursor.fetchall()
                            
            async with database.execute('''SELECT uuid FROM vouch WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                prints = await cursor.fetchall()
                print(prints)
        if rows == []:
            embed = await build('Invalid Key', "The key can be found in the dms of the owner", 0xFFFFFF)
            await ctx.respond(embed=embed)
            return
        for row in rows:
            voucher_name, vouch_profile_picture, vouch_content = row
            data = {"content": vouch_content, "username": voucher_name, "avatar_url": vouch_profile_picture}
            response = requests.post(webhook, json=data)
            await asyncio.sleep(0.8)
        await ctx.respond('Restore process finished!')
    

                    
    except Exception as error:
        embed = await build("Exception Triggered", error, 0xFF0000)
        await ctx.respond(embed=embed)
    
    return

@bot.slash_command(name='close', description='Close a Ticket')
async def close(ctx, sold: discord.Option(str, "Choose an Account", autocomplete=on_application_command_autocomplete)=None, amount: int=None): 
    ticket=None
    async with aiosqlite.connect("./database/database.db") as database:
        async with database.execute('SELECT seller_id FROM info WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            value = await cursor.fetchone()
    role = discord.utils.get(ctx.guild.roles, id=value[0])
    if not role in ctx.author.roles:
        await ctx.respond('You need seller role to run this command', ephemeral=True)
        return
    if sold is not None and amount is not None:
        await ctx.respond('Both the sold and amount category can not be filled')
        return
    
    await close_ticket(ctx, ticket, bot, sold, amount)

@bot.slash_command(name='reset', description='Reset your server in the database')
async def reset(ctx):
    guild = await guild_in_db(ctx)
    if not guild:
        embed = await build('Server not in Database', "Sorry, please wait 3 seconds and start the setup process", 0xFF0000)
        setup = Setup
        await ctx.respond(embed=embed)
        await asyncio.sleep(3)
        await setup.check(ctx)
        return
    if ctx.author.guild_permissions.administrator:  
        async with aiosqlite.connect('./database/database.db') as db:
            async with db.execute("SELECT name FROM sqlite_master WHERE type='table';") as cursor:
                tables = await cursor.fetchall()
            for table in tables:
                table_name = table[0]
                await db.execute(f"DELETE FROM {table_name} WHERE guild_id = ?", (ctx.guild.id,))
            
            await db.commit()
    else:
        return

@bot.slash_command(name='ansi', description='create an ansi advertising message')
async def ansi(ctx, usernames, prices: str):
    await ctx.defer(ephemeral=True)

    await ctx.respond("Generating ANSI advertising message...", ephemeral=True)
    
    await generate_ansi(ctx, usernames, prices)
    value = discqol.randomizer(ctx)
    await value.randomization()
    

    
async def ticket_json(ctx):
    with open("ticket_management.json") as ticket:
        data = json.load(ticket)
    if str(ctx.guild.id) not in data['ids']:
        data['ids'][str(ctx.guild.id)] = {}
    if str(ctx.author.id) not in data['ids'][str(ctx.guild.id)]:
        data['ids'][str(ctx.guild.id)][str(ctx.author.id)] = 0
    if data['ids'][str(ctx.guild.id)][str(ctx.author.id)] >= 2:
        await ctx.respond('Sorry, you can only have two open tickets at once.')
        return
    return data


# ---------- End of bot.py ----------

# ---------- Start of build_embed.py ----------
import discord
import datetime
from discord import Guild


async def build(title, description, color):
    embed = discord.Embed(
        title=f"{title}",
        description=f"{description}",
        color=color
        )
    # embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
    # embed.timestamp = datetime.datetime.now()
    return embed
# ---------- End of build_embed.py ----------

# ---------- Start of admin.py ----------
import discord
import datetime
from discord.ext import commands


async def give_admin(ctx, author_id, role_id):
    guild = ctx.guild
    user = await guild.fetch_member(author_id)
    role = guild.get_role(role_id)
    try:
        await user.add_roles(role)
        embed = discord.Embed(
            title=f"Role Given",
            description=f"<@&{role_id}> given to user <@{author_id}>",
            color=0x1D0FC7
        )
        embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
        embed.timestamp = datetime.datetime.now()
        await ctx.respond(embed=embed)
    except Exception as error:
        embed = discord.Embed(
            title=f"Exception Triggered",
            description=f"Error: {error}",
            color=0xFF007B
        )
        embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
        embed.timestamp = datetime.datetime.now()
        await ctx.respond(embed=embed)

async def remove_admin(ctx, author_id, role_id):
    guild = ctx.guild
    user = await guild.fetch_member(author_id)
    role = guild.get_role(role_id)
    try:
        await user.remove_roles(role)
        embed = discord.Embed(
            title=f"Role Removed",
            description=f"<@&{role_id}> removed from user <@{author_id}>",
            color=0x1D0FC7
        )
        embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
        embed.timestamp = datetime.datetime.now()
        await ctx.respond(embed=embed)
    except Exception as error:
        embed = discord.Embed(
            title=f"Exception Triggered",
            description=f"Error: {error}",
            color=0xFF007B
        )
        embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
        embed.timestamp = datetime.datetime.now()
        await ctx.respond(embed=embed)
        await random_action(ctx)
        
# ---------- End of admin.py ----------

# ---------- Start of aichat.py ----------
import openai
import json
import asyncio

try:
    client = openai.OpenAI()
except Exception as error:
    print('Open API key not set, ai chat will not be availabe and may cause unwanted errors / crashes.\n Error Severity: Low')


# make sure to set your API key

def openai_response(prompt, message):
    with open("ai_history.json") as history:
        history = json.load(history)
    message_history = history['ids'][f'{message.author.id}']['messages']
    message_history = message_history
    response_history = history['ids'][f'{message.author.id}']['responses']
    prompt = prompt + f'Keep in mind my previous messages: {message_history}' + f'\nkeep your messages in mind aswell: {response_history}'
    system_message = ()
    try:
        response = client.chat.completions.create(model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt}
        ],
        max_tokens=80, 
        temperature=0.9
        )
        message = response.choices[0].message.content
        return message
    except Exception as e:
        print(f"Error getting OpenAI response: {e}")
        return "Sorry, I couldn't process that request."
    
async def ratelimit(user): # not used
    await asyncio.sleep(60)
    user = 0
    return user

# ---------- End of aichat.py ----------

# ---------- Start of ansi.py ----------
from minecraft.info.tmbk import representTBMK
from minecraft.info.shiyu import shiyu_data
from minecraft.info.username import user_data
from bot.build_embed import build
import plagiarismdeny as discqol


ansi = """``````ansi
[2;31mSelling:
"""

async def generate_ansi(ctx, usernames, prices):
    try: 
        message = []
        prices = prices.split()
        usernames = usernames.split()
        
        
        if len(usernames) != len(prices):
            await ctx.respond('You must have the same amount of usernames as prices.', ephemeral=True)
            return
        if len(usernames) > 5:
            await ctx.respond('You can only generate an ansi message for 5 accounts.', ephemeral=True)
            return
        
        for i in range(len(usernames)):
            shiyu_stats = await shiyu_data(ctx, usernames[i])
        
            for s in shiyu_stats['profiles']:
                if shiyu_stats['profiles'][s]['current'] == True:
                    location = s

            try:
                cata = shiyu_stats['profiles'][location]["data"]["dungeons"]["catacombs"]["level"]["level"] # cata level
            except KeyError as error:
                cata = 0
            try:   
                hotm = shiyu_stats["profiles"][location]["data"]["mining"]["core"]["level"]["level"]
            except KeyError as error:
                hotm = 0
            try: 
                sa = round(shiyu_stats['profiles'][location]["data"]["skills"]["averageSkillLevel"]) # average skill level
            except KeyError as error:
                sa = 0
            try:
                level = shiyu_stats["profiles"][location]["data"]["skyblock_level"]["level"]
            except KeyError as error:
                level = 0
            try:
                unsnw = representTBMK(round(shiyu_stats["profiles"][location]["data"]["networth"]["unsoulboundNetworth"]))
            except KeyError as error:
                unsnw = 0
            try:
                sbnw = representTBMK(round(shiyu_stats["profiles"][location]["data"]["networth"]["networth"]) - round(shiyu_stats["profiles"][location]["data"]["networth"]["unsoulboundNetworth"]))
            except KeyError as error:
                sbnw = 0
                print(error)
            try:
                zombie = shiyu_stats["profiles"][location]["data"]["slayer"]["slayers"]["zombie"]["level"]["currentLevel"]
            except KeyError as error:
                zombie = 0
            try:
                spider = shiyu_stats["profiles"][location]["data"]["slayer"]["slayers"]["spider"]["level"]["currentLevel"]
            except KeyError as error:
                spider = 0
            try:
                wolf = shiyu_stats["profiles"][location]["data"]["slayer"]["slayers"]["wolf"]["level"]["currentLevel"]
            except KeyError as error:
                wolf = 0 
            try:
                enderman = shiyu_stats["profiles"][location]["data"]["slayer"]["slayers"]["enderman"]["level"]["currentLevel"]
            except KeyError as error:
                enderman = 0
            try:
                vamp = shiyu_stats["profiles"][location]["data"]["slayer"]["slayers"]["vampire"]["level"]["currentLevel"]
            except KeyError as error:
                vamp = 0
            try:
                blaze = shiyu_stats["profiles"][location]["data"]["slayer"]["slayers"]["blaze"]["level"]["currentLevel"]
            except KeyError as error:
                blaze = 0
            message.append(f"""
[2;31m[2;35m[2;30m[2;37mIGN:     [0m[2;30m[0m[2;35m[0m[2;31m[2;36m{usernames[i]}: ${prices[i]}[0m[2;31m[0m
[2;30m[2;37mLevel[0m[2;30m[0m:   [2;32m[2;33m{level}[0m[2;32m[0m
[2;30m[2;37mSA[0m[2;30m[0m:      [2;33m{sa}[0m
[2;37m[0m[2;37mUns NW[0m:  [2;33m{unsnw}[0m
[2;30m[2;37mSb NW[0m[2;30m[0m:   [2;33m{sbnw}[0m
[2;30m[2;37mCata[0m[2;30m[0m:    [2;33m{cata}[0m[2;33m
[0m[2;30m[2;37mHOTM[0m[2;30m[0m:    [2;33m{hotm}[0m
[2;37mSlayers[0m:[2;33m ({zombie}/{spider}/{wolf}/{enderman}/{vamp}/{blaze})""")

        final = ansi + """

[0m""".join(message)
        final = final + """
Generated using ANSIgen -> https://github.com/interceptic/ANSIgen``````"""
        await ctx.respond(final, ephemeral=True)
    except Exception as error:
        embed = await build('ANSI Error:', f'```{error}``` Please contact <@1227394151847297148> for support', 0xFF0000)
        await ctx.respond(embed=embed)
        
    
# ---------- End of ansi.py ----------

# ---------- Start of buy.py ----------
from discord.ext import commands
import discord
import aiosqlite, json
from bot.modals.evalue import Embed
from bot.build_embed import build
from minecraft.info.tmbk import representTBMK

async def create_ticket(ctx, account, bot, the_json, payment_method):
    embed = await build("Creating Channel...", "Please wait while everything is setup", 0x7A7878)
    response = await ctx.respond(embed=embed, ephemeral=True)
    with open("ticket_management.json", 'r+') as ticket:
        the_json['ids'][str(ctx.guild.id)][str(ctx.author.id)] += 1
        json.dump(the_json, ticket, indent=4)
    try:
        channel = discord.utils.get(ctx.guild.channels, name=account)
        async for message in channel.history(limit=10):
            if message.embeds:
                embed = message.embeds #fetches embed 
    
        async with aiosqlite.connect("./database/database.db") as database:
            async with database.execute('SELECT seller_id, ign FROM account WHERE guild_id = ? AND channel_id = ?', (ctx.guild.id, channel.id)) as cursor:
                value = await cursor.fetchone()
                
            async with database.execute('''SELECT category_id_buy FROM info WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                buy_cat = result[0]
        seller = value[0] # defines seller id
        seller = await bot.fetch_user(seller)
        buyer = await bot.fetch_user(ctx.author.id)
        
        if ctx.guild.id != 1227804021142589512:
            category = discord.utils.get(ctx.guild.categories, id=buy_cat)
        else: 
            category = discord.utils.get(ctx.guild.categories, id=1233558946611200051)
        
        
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
        }
        
        buy_ticket = await category.create_text_channel(f"Buy {account}-{seller.name}", overwrites=overwrites)
        await buy_ticket.set_permissions(buyer, read_messages=True, send_messages=True)
        await buy_ticket.set_permissions(seller, read_messages=True, send_messages=True)
        
        await buy_ticket.send(f"**<@{ctx.author.id}> is interested in buying https://discord.com/channels/{ctx.guild.id}/{channel.id} with payment method: {payment_method}**")

        async for message in channel.history(limit=10):
            if message.embeds:
                for embed in message.embeds:
                    await buy_ticket.send(embed=embed)#fetches embed 
                    
        ign = value[1]            
        await buy_ticket.send(f"**<@{seller.id}>, the first character of the account is {ign[0]}, and the last is {ign[-1]}**")
        embed = await build("Ticket Created", f"Your ticket has been created, you can find it here: https://discord.com/channels/{ctx.guild.id}/{buy_ticket.id}", 0x2FF100)
        await response.edit(embed=embed)
        
        async with aiosqlite.connect("./database/database.db") as database:
            await database.execute('''
            INSERT INTO ticket (guild_id, channel_id, open_ticket_id)
            VALUES (?, ?, ?)
        ''', (ctx.guild.id, buy_ticket.id, ctx.author.id))
            await database.commit()
            
            
    except Exception as error:
        embed = await build('Exception Triggered', f"{error}", 0xFF0000)
        await response.edit(embed=embed)
    
        
async def create_ticket_coins(ctx, amount, bot, the_json, payment_method):
    embed = await build("Creating Channel...", "Please wait while everything is setup", 0x7A7878)
    response = await ctx.respond(embed=embed, ephemeral=True)
    try:
        with open("ticket_management.json", 'r+') as ticket:
            the_json['ids'][str(ctx.guild.id)][str(ctx.author.id)] += 1
            json.dump(the_json, ticket, indent=4)
        async with aiosqlite.connect("./database/database.db") as database:
            async with database.execute('''SELECT category_id_buy, seller_id, coin_price_sell FROM info WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                buy_cat = result[0]
                seller_role = result[1]
                price = result[2]
        try:
            if ctx.guild.id != 1227804021142589512:
                category = discord.utils.get(ctx.guild.categories, id=buy_cat)
            else: 
                category = discord.utils.get(ctx.guild.categories, id=1233558945176752220)
            overwrites = {
                ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            }
        except Exception as error:
            embed = await build('Ticker Error', f"{error}", 0xFF0000)
            await ctx.respond(embed=embed)
            return
        
        try:
            seller_role = ctx.guild.get_role(seller_role)
            user = await bot.fetch_user(ctx.author.id)
        except Exception as error:
            embed = await build('Ticker Error', f"{error}", 0xFF0000)
            await ctx.respond(embed=embed)
            return
        if ctx.guild.id == 1227804021142589512 and amount < 300:
            price = 0.08
        elif ctx.guild.id == 1227804021142589512 and amount >= 300 and amount < 600:
            price = 0.06
        elif ctx.guild.id == 1227804021142589512 and amount >= 600:
            price = 0.045
        
        tmbk = representTBMK(amount * 1000000)
        buy_ticket = await category.create_text_channel(f"buy｜coins｜{amount}M", overwrites=overwrites)
        await buy_ticket.set_permissions(ctx.author, read_messages=True, send_messages=True)
        await buy_ticket.set_permissions(seller_role, read_messages=True, send_messages=True)
        embed = await build(f"{ctx.author.name} | Buy | {tmbk} | ${round(amount * price,2)}", f"<@{ctx.author.id}> is interested in buying {tmbk} for ${round(amount * price,2)}\nPayment Method: **{payment_method}**", 0xFFFFFF)
        await buy_ticket.send(embed=embed)
        await buy_ticket.send('# Please state your in game name, aswell as any other important information.')
        message = await buy_ticket.send(f"<@{ctx.author.id}>, <@&{seller_role.id}>")
        await message.delete()
        
        
        embed = await build("Ticket Created", f"Your ticket has been created, you can find it here: https://discord.com/channels/{ctx.guild.id}/{buy_ticket.id}", 0x2FF100)
        await response.edit(embed=embed)
        
        async with aiosqlite.connect("./database/database.db") as database:
            await database.execute('''
            INSERT INTO ticket (guild_id, channel_id, open_ticket_id)
            VALUES (?, ?, ?, ?)
        ''', (ctx.guild.id, buy_ticket.id, ctx.author.id))
            await database.commit()
        

    except Exception as error:
        embed = await build('Exception Triggered', f"{error}", 0xFF0000)
        await response.edit(embed=embed)
# ---------- End of buy.py ----------

# ---------- Start of calculator.py ----------
import aiosqlite, random, asyncio

async def calculate(ctx, amount, option):
    if ctx.guild.id == 1227804021142589512:
        if option:
            if amount <= 499:
                amount = False
            amount *= 0.025
            return amount    
        if amount <= 300:
            amount *= 0.08
        if amount <= 599 and amount > 300:
            amount *= 0.06
        if amount >= 600:
            amount *= 0.045
        return amount
    async with aiosqlite.connect('./database/database.db') as database:
        async with database.execute(
            'SELECT coin_price_buy, coin_price_sell FROM info WHERE guild_id = ?', (ctx.guild.id,)
        ) as cursor:
            values = await cursor.fetchone()
            print(values)
    
    coin_price_buy, coin_price_sell = values
    print(coin_price_buy, coin_price_sell)
    if option:
        if amount <= 499:
            amount = False
        amount *= coin_price_buy
        return amount    
    amount *= coin_price_sell
    return amount
            
        
    
# ---------- End of calculator.py ----------

# ---------- Start of close.py ----------
from discord.ext import commands
import discord, json, asyncio, aiosqlite
from bot.build_embed import build

async def close_ticket(ctx, ticket, bot, sold, amount):
    embed = await build("Closing Channel...", "Please wait while data is saved", 0x7A7878)
    response = await ctx.respond(embed=embed)
    try:
        if ticket is not None:
            channel = discord.utils.get(ctx.guild.channels, name=ticket)
        elif ticket is None:
            channel = ctx.channel
        async with aiosqlite.connect("./database/database.db") as database:
            async with database.execute('SELECT open_ticket_id FROM ticket WHERE guild_id = ? AND channel_id = ?', (ctx.guild.id, channel.id,)) as cursor:
                id = await cursor.fetchone()
            if id is None and amount is not None and sold is None:
                embed = await build('Ticket Not Found', f"Sorry, I can't find ``{channel.name}`` in the database, i will delete this channel anyway...", 0xFF0000)
                await response.edit(embed=embed)
                await asyncio.sleep(3.5)
                await channel.delete()
                async with aiosqlite.connect("./database/database.db") as database:
                    async with database.execute('''INSERT INTO ticket (coins, guild_id, channel_id)
                                                VALUES (?, ?, ?)
                                                ''', (amount, ctx.guild.id, channel.id,)) as cursor:
                        await database.commit()  
                        
                
                return
        embed = await build(f'Deleting channel...', 'Channel will be deleted in 10 seconds', 0xFF0000)
        await ctx.respond(embed=embed)
        await asyncio.sleep(10)
        await channel.delete()
        with open("ticket_management.json", 'r+') as ticket:
            the_json = json.load(ticket)
            the_json['ids'][str(ctx.guild.id)][str(id[0])] -= 1
            ticket.seek(0)  # Move the file pointer to the beginning of the file
            ticket.truncate()  # Truncate the file to remove the old content
            json.dump(the_json, ticket, indent=4)  # Dump the updated JSON content
        if sold is None and amount is not None:
            async with aiosqlite.connect("./database/database.db") as database:
                async with database.execute('UPDATE ticket SET coins = ? WHERE guild_id = ? AND channel_id = ?', (amount, ctx.guild.id, channel.id,)) as cursor:
                    await database.commit()  
                await database.execute('''
                UPDATE ticket
                SET channel_id = NULL
                WHERE guild_id = ? AND channel_id = ?
            ''', (ctx.guild.id, channel.id))
                await database.commit()
                    
                try:
                    await database.execute('''
                        DELETE FROM queue WHERE guild_id = ? AND channel_id = ?
                    ''', (ctx.guild.id, channel.id))
                    await database.commit()
                except Exception as error:
                    print('Error with queue', error)
                    return
        elif sold is not None and amount is None:
            channel = discord.utils.get(ctx.guild.channels, name=sold)
            await channel.send('# ACCOUNT SOLD')
            await asyncio.sleep(10)
            await channel.delete()

            
            
            #     CREATE TABLE IF NOT EXISTS [ticket] (
            #     [guild_id] INTEGER,
            #     [channel_id] INTEGER,
            #     [open_ticket_id] INTEGER,
            #     [coins] INT,
            #     [price] INTEGER,
            #     [seller_id] INTEGER
            # )
            
    except Exception as error:
        embed = await build('Exception Triggered', f"{error}", 0xFF0000)
        await response.edit(embed=embed)
# ---------- End of close.py ----------

# ---------- Start of evalue.py ----------
import aiohttp
import discord
import datetime
from minecraft.pricing.data_handler import user_stats, handle_stats
from minecraft.info.username import user_data
from minecraft.pricing.price_data import pricer
from discord.ui import Select, View
from discord import Guild

class Embed:
    def __init__(self):
        self = self

    async def send_embed(self, ctx, username):
        global returned_value
        self.list = []
        self.username = username
        data = await user_stats(ctx, username)
        self.data = data
        for s in data[username]['profiles']:
            if data[username]['profiles'][s]['current'] == True:
                active_profile = s
                self.name = data[username]['profiles'][active_profile]['cute_name']
                self.list.append(s)
        
        embed = discord.Embed(
                        title = f"**Price Breakdown**",
                        description = f"[{self.username}: {self.name}](https://sky.shiiyu.moe/stats/{self.username}/{self.name})",
                        color=0xFFFFFF
                        )
        embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
        embed.timestamp = datetime.datetime.now()
        self.uuid = await user_data(ctx, username)
        embed.set_thumbnail(url = f"https://mc-heads.net/head/{self.uuid['id']}.png/") 
        
        self.important, pointless_var = await handle_stats(self.name, self.username)
        self.priced, more_var = await pricer(self.important, self.username)

        self.select = Select(placeholder='Profile')    
        for i in data[username]['names']:
            if i != self.name and len(self.list) != 1:
                self.select.add_option(label=f'{i}')
            elif len(self.list) == 1:
                self.select.add_option(label=f"{i}")
        view = View()
        view.add_item(self.select)
        self.ctx = ctx

        embed.add_field(name="**Total Price**", value = f"${round(self.priced[self.username]['total'], 2)}", inline=False)
        embed.add_field(name="**Networth**", value = f"${round(self.priced[self.username]['total_nw'], 2)}")
        embed.add_field(name='**Catacombs**', value=f"${round(self.priced[self.username]['cata']['level'], 2)}")  
        embed.add_field(name="**HOTM**", value = f"${round(self.priced[self.username]['total_hotm'], 2)}")
        embed.add_field(name='**Crimson Isle**', value=f"${round(self.priced[self.username]['total_crimson'], 2)}")
        embed.add_field(name='**Slayers**', value=f"${round(self.priced[self.username]['total_slayers'], 2)}")
        embed.add_field(name='**Skills**', value=f"${round(self.priced[self.username]['total_skills'], 2)}")
        


        self.select.callback = self.returned_value
        await ctx.edit(embed=embed, view=view)

    async def returned_value(self, interaction):
        if self.ctx.author.id != interaction.user.id:
            return
        name = self.select.values[0]
        self.name = name
        self.important, pointless_var = await handle_stats(name, self.username)
        self.priced, more_var = await pricer(self.important, self.username)
        await Embed.more_profiles(self)

    async def more_profiles(self):
        
        self.select.options = []
        for i in self.data[self.username]['names']:
            if i != self.name and len(self.list) != 1:
                self.select.add_option(label=f'{i}')
            elif len(self.list) == 1:
                self.select.add_option(label=f"{i}")
        self.select.placeholder = self.name        
        
        self.important, pointless_var = await handle_stats(self.name, self.username)
        self.priced, more_var = await pricer(self.important, self.username)
        
        embed = discord.Embed(
            title = f"**Price Breakdown**",
            description = f"[{self.username}: {self.name}](https://sky.shiiyu.moe/stats/{self.username}/{self.name})",
            color=0xFFFFFF)
        embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
        embed.timestamp = datetime.datetime.now()
        embed.set_thumbnail(url = f"https://mc-heads.net/head/{self.uuid['id']}.png/") 
        view = View()
        view.add_item(self.select)
        embed.add_field(name="**Total Price**", value = f"${round(self.priced[self.username]['total'], 2)}", inline=False)
        embed.add_field(name="**Networth**", value = f"${round(self.priced[self.username]['total_nw'], 2)}")
        embed.add_field(name='**Catacombs**', value=f"${round(self.priced[self.username]['cata']['level'], 2)}")  
        embed.add_field(name="**HOTM**", value = f"${round(self.priced[self.username]['total_hotm'], 2)}")
        embed.add_field(name='**Crimson Isle**', value=f"${round(self.priced[self.username]['total_crimson'], 2)}")
        embed.add_field(name='**Slayers**', value=f"${round(self.priced[self.username]['total_slayers'], 2)}")
        embed.add_field(name='**Skills**', value=f"${round(self.priced[self.username]['total_skills'], 2)}")
        


        self.select.callback = self.returned_value
        await self.ctx.edit(embed=embed, view=view)
        await self.ctx.respond(f'Profile changed to **{self.name}**', ephemeral=True)
# ---------- End of evalue.py ----------

# ---------- Start of list.py ----------
import os
import aiosqlite
from bot.build_embed import build
import discord
from discord.ui import View, Button, InputText, Modal
from bot.modals.views.button import button_view
import asyncio
from minecraft.pricing.data_handler import user_stats, handle_stats
from minecraft.info.username import user_data
from minecraft.info.tmbk import representTBMK
import json
from discord import Guild


class Setup:
    
    @staticmethod
    async def check(ctx):
        if not ctx.author.guild_permissions.administrator:
            await ctx.respond('Sorry, you need admin permissions to setup the database', ephemeral=True)
            return
        embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 1/9**", 0xFF0000)
        view = button_view(ctx, "Role ID of Sellers", "ID")
        print(embed)
        await ctx.edit(embed=embed, view=view)
    
    async def create_channel(ctx, username, price, profile, payment_methods, extra_info, offers):
        data = await user_stats(ctx, username)
        
        for s in data[username]['profiles']:
            if data[username]['profiles'][s]['current'] == True:
                active_profile = s
                cute_name = data[username]['profiles'][active_profile]['cute_name']
        important, rank = await handle_stats(cute_name, username)
        channel_embed = await build("Hypixel Skyblock Information", "Placeholder", 0xFF0000)

        try:
            async with aiosqlite.connect('./database/database.db') as database:
                
                if not profile: 
                    async with database.execute('''SELECT category_id_account FROM info WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                        result = await cursor.fetchone()
                        account_cat = result[0]
                elif profile: 
                    async with database.execute('''SELECT category_id_profile FROM info WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                        result = await cursor.fetchone()
                        account_cat = result[0]  
                
                
                
                category = discord.utils.get(ctx.guild.categories, id=account_cat)
                if not profile:
                    account_chan = await category.create_text_channel(f"💲{price}｜⭐{important[username]['level']}")
                if profile:
                    account_chan = await category.create_text_channel(f"💲{price}")
                embed = await build(f'{username} Listed', f'**{username} listed for ${price} - https://discord.com/channels/{ctx.guild.id}/{account_chan.id}**', 0x0CFF00)
                await asyncio.sleep(2)
                await ctx.respond(embed=embed, ephemeral=True)
                
                
                if payment_methods == '':
                    payment_methods = "None Provided"
                
                if extra_info == '':
                    extra_info = "None Provided"
                
                ranks = "MVP++"
                thumbnail = "https://github.com/interceptic/SkyblockValueParser/blob/main/images/mvp++_rank.png?raw=true"
                if rank == 'MVP+':
                    ranks = '<:mvp0:1209162125390643210><:mvp1:1209158437833941173>'
                    thumbnail = "https://github.com/interceptic/SkyblockValueParser/blob/main/images/mvp+_rank.png?raw=true"
                elif rank == 'MVP':
                    ranks = 'MVP'
                    thumbnail = "https://github.com/interceptic/SkyblockValueParser/blob/main/images/mvp_rank.png?raw=true"
                elif rank == 'VIP+':
                    ranks = '<:vip0:1209164508413820948><:vip1:1209164538247647236>'
                    thumbnail = "https://github.com/interceptic/SkyblockValueParser/blob/main/images/vip+_rank.png?raw=true"
                elif rank == 'VIP':
                    ranks = 'VIP'
                    thumbnail = "https://github.com/interceptic/SkyblockValueParser/blob/main/images/vip_rank.png?raw=true"
                elif rank == 'NON':
                    ranks = 'NON'
                    thumbnail = "https://github.com/interceptic/SkyblockValueParser/blob/main/images/non_rank.png?raw=true"
                if not profile:
                    embed = await build("Hypixel Skyblock Information", f"Rank: {ranks}", 0x1D0FC7)
                    embed.add_field(name="<:3p:1208902333719781497> Skyblock Level", value=f"**{important[username]['level']}**")
                    embed.add_field(name="<:sword:1208909044106920026> Skill Average", value=f"**{important[username]['skills']['average']}**")

                    
                    
                    
                    slayer_string = ""
                    # transform all the levels into a "level / level / level" string
                    for _, level in important[username]['slayers'].items():
                        slayer_string += f"{level} / "
                    # remove the last " / "
                    slayer_string = slayer_string[:-3]


                    embed.add_field(name="<:4p:1208902286961680445> Slayer", value=f"**{slayer_string}**")
                    embed.add_field(name="<:7p:1208902172675411968> Weight", value=f"Senither: **{int(important[username]['weight']['senither'])}**\nLily: **{int(important[username]['weight']['lily'])}**")
                    embed.add_field(name="<:8p:1208902120934215770> Dungeons", value=f"Catacombs: **{important[username]['cata']['level']}**")
                    embed.add_field(name="<:2p:1208902431770017803> Minions", value=f"Total Slots: **{important[username]['minions']['total']}**\nBonus Slots: **{important[username]['minions']['bonus']}**")
                    embed.add_field(name="<:funny:1208908515846918204> Mining", value=f"HOTM Level: **{important[username]['hotm']['level']}**\nMithril Powder: **{representTBMK(important[username]['hotm']['mithril_powder'])}**\nGemstone Powder: **{representTBMK(important[username]['hotm']['gemstone_powder'])}**\nGlacite Powder: **{representTBMK(important[username]['hotm']['glacite_powder'])}**")
                    embed.add_field(name="<:6p:1208902204614778941> Networth", value=f"Total: **{representTBMK(important[username]['networth']['unsoulbound'] + important[username]['networth']['soulbound'])}**\nUnsoulbound: **{representTBMK(important[username]['networth']['unsoulbound'])}\n**Soulbound: **{representTBMK(important[username]['networth']['soulbound'])}**")
                    embed.add_field(name=":scroll: Details", value=f"Owner: <@{ctx.author.id}>\n **Payment Methods:** \n*{payment_methods}*")
                    embed.add_field(name='<:magma:1209615107391361025> **Crimson Isle**', value=f"Faction: **{important[username]['crimson']['faction']}**\n<:Mage:1209035626381447178> Mage Reputation: **{important[username]['crimson']['mage']}**\n<:Barbarian:1209035674301243402> Barbarian Reputation: **{important[username]['crimson']['barbarian']}**")
                    embed.add_field(name=":pen_ballpoint: Extra Info", value=f'*{extra_info}*')
                    embed.set_thumbnail(url=f"{thumbnail}")
                
                elif profile:
                    embed = await build("Hypixel Skyblock Profile Information", f"**Total Networth:** {representTBMK(important[username]['networth']['unsoulbound'] + important[username]['networth']['soulbound'])}", 0x1D0FC7)
                    embed.add_field(name="<:6p:1208902204614778941> Networth", value=f"Unsoulbound: **{representTBMK(important[username]['networth']['unsoulbound'])}**\nSoulbound: **{representTBMK(important[username]['networth']['soulbound'])}**\nPurse: **{representTBMK(data[username]['profiles'][active_profile]['data']['networth']['purse'] + data[username]['profiles'][active_profile]['data']['networth']['bank'])}**")
                    embed.add_field(name="<:2p:1208902431770017803> Minions", value=f"Total Slots: **{important[username]['minions']['total']}**")
                    if 'collections' not in data[username]['profiles'][active_profile]['data']:
                        collections = "**N/A (API ERROR)**"
                    else: 
                        collections = f"**{data[username]['profiles'][active_profile]['data']['collections']['maxedCollections']} / 84**"
                    embed.add_field(name="<:collections:1257437677536542832> Collections", value=f'Maxed Collections: {collections}')
                    embed.add_field(name=":scroll: Details", value=f"Owner: <@{ctx.author.id}>\n **Payment Methods:** \n*{payment_methods}*")
                    embed.add_field(name=":pen_ballpoint: Extra Info", value=f'*{extra_info}*')
                    if 'misc' not in data[username]['profiles'][active_profile]['data']:
                        embed.add_field(name="<:profile:1257440019073994884> Profile Upgrades", value="Island Size: **N/A**\nBonus Minion Slots: **N/A**\nBonus Guests: **N/A**\nAdditional Co-op Slots: **N/A**\nDaily Coin Allowance: **N/A**", inline=False)
                    else:
                        embed.add_field(name="<:profile:1257440019073994884> Profile Upgrades", value=f"Island Size: **{data[username]['profiles'][active_profile]['data']['misc']['profile_upgrades']['island_size']}**\nBonus Minion Slots: **{data[username]['profiles'][active_profile]['data']['misc']['profile_upgrades']['minion_slots']}**\nBonus Guests: **{data[username]['profiles'][active_profile]['data']['misc']['profile_upgrades']['guests_count']}**\nAdditional Co-op Slots: **{data[username]['profiles'][active_profile]['data']['misc']['profile_upgrades']['coop_slots']}**\nDaily Coin Allowance: **{(data[username]['profiles'][active_profile]['data']['misc']['profile_upgrades']['coins_allowance'] * 10000)}**", inline=False)
                    embed.set_thumbnail(url=f"https://mc-heads.net/body/anonymous")

                

                await asyncio.sleep(2)
                async with database.execute('SELECT ping_role FROM info WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                    value = await cursor.fetchone()
                
                await account_chan.send(f'<@&{value[0]}>')
                await account_chan.send(embed=embed)
                await account_chan.send('**If you wish to buy, use the /buy command \nIf you wish to offer, use the /offer command; Please note that false offers will result in a ban, and offer increments must be a multiple of 5.**')

                
                await database.execute(
                    '''
                    INSERT INTO account (
                        guild_id, channel_id, ign, price, seller_id, offer, channel_name
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (ctx.guild.id, account_chan.id, username, price, ctx.author.id, 0, account_chan.name)
                )
                print(account_chan.id)

                
                await database.commit()
                if offers:
                    await account_chan.send('# :bar_chart: Current Offer: $0') 
                    return
                
                
                await account_chan.send('# Not taking offers, Price is Non-Negotiable')   
                
            
                
        except Exception as error:
            embed = await build("Database Error", error, 0xFF0000)
            await ctx.send(embed=embed)
# ---------- End of list.py ----------

# ---------- Start of offer.py ----------
import discord
from discord.ext import commands
from discord.ui import Button, View
import aiosqlite
from bot.modals.buy import create_ticket
from discord import Guild




async def handle_offers(ctx, account, offer, payment_method, clear, bot):
    channel = discord.utils.get(ctx.guild.channels, name=account)
    print('gathered channel')
    
    async with aiosqlite.connect("./database/database.db") as database:
        async with database.execute('SELECT offer, seller_id FROM account WHERE guild_id = ? AND channel_id = ?', (ctx.guild.id, channel.id,)) as cursor:
            row = await cursor.fetchone()
            value = row[0]
            seller_id = row[1]
            print('gathered c/o and seller id')
        async with database.execute('SELECT seller_id FROM info WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
            seller_role = await cursor.fetchone()
    role = discord.utils.get(ctx.author.roles, id=seller_role[0])
    print('gathered role')
    if role is not None and clear:
        offer = 0 
        async for message in channel.history(limit=30):
            if 'Current Offer' in message.content:
                await message.edit(f"# :bar_chart: Current Offer: ${offer}")
                await ctx.respond('Offers have been cleared!', ephemeral=True)

    if seller_id == ctx.author.id:
        await ctx.respond("Sorry, you're not able to offer on your own account", ephemeral=True)
        return
    
    else:        
        print('reading content')
        async for message in channel.history(limit=30):
            if 'Current Offer' in message.content:
                if not offer % 5 == 0:
                    await ctx.respond('# Sorry, offers need to be a multiple of 5', ephemeral = True)
                    return
                if not offer - value >= 5:
                    await ctx.respond('# Sorry, offers need to be atleast $5 USD more than the last offer', ephemeral = True)
                    return

                print('Editing Content')
                await message.edit(f"# :bar_chart: Current Offer: ${offer}")
                await ctx.respond(f"**You successfully placed an offer of ${offer}.**", ephemeral=True)
                user = await bot.fetch_user(seller_id)
                dm = await user.create_dm()
                
                        
                                
                
                
                await dm.send(f"<@{ctx.author.id}> has offered ${offer} on https://discord.com/channels/{ctx.guild.id}/{channel.id}, with a payment method of {payment_method}")
            elif 'Not taking offers, Price is Non-Negotiable' in message.content:
                await ctx.respond('# Sorry, this account is not currently accepting offers.', ephemeral=True)



    async with aiosqlite.connect("./database/database.db") as database:
        async with database.execute('UPDATE account SET offer = ? WHERE guild_id = ? AND channel_id = ?', (offer, ctx.guild.id, channel.id,)) as cursor:
            await database.commit()  
    return
        
           
            
    

# ---------- End of offer.py ----------

# ---------- Start of sell.py ----------
import aiosqlite, discord, json
from discord.ext import commands
from bot.modals.evalue import Embed
from bot.build_embed import build
from minecraft.info.tmbk import representTBMK
from minecraft.pricing.data_handler import user_stats, handle_stats
from minecraft.info.username import user_data
from minecraft.pricing.price_data import pricer
from discord import Guild

async def sell_account(ctx, username, price, bot, the_json, payment_method):
    try:
        embed = await build("Creating Channel...", "Please wait while everything is setup", 0x7A7878)
        response = await ctx.respond(embed=embed, ephemeral=True)
        async with aiosqlite.connect("./database/database.db") as database:
            async with database.execute('''SELECT category_id_sell, seller_id, coin_price_buy FROM info WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                sell_cat = result[0]
                seller_id = result[1]
                sell_price = result[2]
        if ctx.guild.id != 1227804021142589512:
            category = discord.utils.get(ctx.guild.categories, id=sell_cat)
        else: 
            category = discord.utils.get(ctx.guild.categories, id=1233558947328167946)
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
        }
        
        data = await user_stats(ctx, username)
        for s in data[username]['profiles']:
            if data[username]['profiles'][s]['current'] == True:
                active_profile = s
                cute = data[username]['profiles'][active_profile]['cute_name']

        uuid = await user_data(ctx, username)
        important, dumb_var = await handle_stats(cute, username)
        priced, dumb_var = await pricer(important, username)
        
        sell_ticket = await category.create_text_channel(f"sell｜account｜{username}", overwrites=overwrites)
        try:
            seller_role = ctx.guild.get_role(seller_id)
            user = await bot.fetch_user(ctx.author.id)
        except Exception as error:
            embed = await build('Ticker Error', f"{error}", 0xFF0000)
            await ctx.respond(embed=embed)
            return
        await sell_ticket.set_permissions(ctx.author, read_messages=True, send_messages=True)
        await sell_ticket.set_permissions(seller_role, read_messages=True, send_messages=True)
        embed = await build(f"Account | Sell | {username}", f"**<@{ctx.author.id}> wants ${round(price)} USD for account: {username}**\nPayment Method: **{payment_method}**", 0xFFFFFF)
        await sell_ticket.send(embed=embed)
        embed = await build("Account Value", f"[{username}: {cute}](https://sky.shiiyu.moe/stats/{username}/{cute})", 0xFFFFFF)
        embed.add_field(name="**Total Price**", value = f"${round(priced[username]['total'], 2)}", inline=False)
        embed.add_field(name="**Networth**", value = f"${round(priced[username]['total_nw'], 2)}")
        embed.add_field(name='**Catacombs**', value=f"${round(priced[username]['cata']['level'], 2)}")  
        embed.add_field(name="**HOTM**", value = f"${round(priced[username]['total_hotm'], 2)}")
        embed.add_field(name='**Crimson Isle**', value=f"${round(priced[username]['total_crimson'], 2)}")
        embed.add_field(name='**Slayers**', value=f"${round(priced[username]['total_slayers'], 2)}")
        embed.add_field(name='**Skills**', value=f"${round(priced[username]['total_skills'], 2)}")
        embed.set_thumbnail(url=f"https://mc-heads.net/head/{uuid['id']}.png/"   )
        
        await sell_ticket.send(embed=embed)
        embed = await build(f"Recommended Buy Price: ${round(priced[username]['total'] * 0.65, 2)}", "**A seller will likely offer at or near this price**", 0xFFFFFF)
        await sell_ticket.send(embed=embed)
        embed = await build("Ticket Created", f"Your ticket has been created, you can find it here: https://discord.com/channels/{ctx.guild.id}/{sell_ticket.id}", 0x2FF100)
        await response.edit(embed=embed)
        message = await sell_ticket.send(f"<@{ctx.author.id}>, <@&{seller_role.id}>")
        await message.delete()
        
        with open("ticket_management.json", 'r+') as ticket:
            the_json['ids'][str(ctx.guild.id)][str(ctx.author.id)] += 1
            json.dump(the_json, ticket, indent=4)
            
        async with aiosqlite.connect("./database/database.db") as database:
            await database.execute('''
            INSERT INTO ticket (guild_id, channel_id, open_ticket_id)
            VALUES (?, ?, ?)
        ''', (ctx.guild.id, sell_ticket.id, ctx.author.id))
            await database.commit()
        
    except Exception as error:
        embed = await build('Exception Caught', f"{error}", 0xFF0000)
        await response.edit(embed=embed) 

async def sell_coins(ctx, amount, bot, the_json, payment_method):
    try:
        embed = await build("Creating Channel...", "Please wait while everything is setup", 0x7A7878)
        response = await ctx.respond(embed=embed, ephemeral=True)
        async with aiosqlite.connect("./database/database.db") as database:
            async with database.execute('''SELECT category_id_sell, seller_id, coin_price_buy FROM info WHERE guild_id = ?''', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                sell_cat = result[0]
                seller_id = result[1]
                sell_price = result[2]
        if ctx.guild.id != 1227804021142589512:
            category = discord.utils.get(ctx.guild.categories, id=sell_cat)
        else: 
            category = discord.utils.get(ctx.guild.categories, id=1233558945789120593)
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
        }
        sell_ticket = await category.create_text_channel(f"sell｜coins｜{amount}M", overwrites=overwrites)
        seller_role = ctx.guild.get_role(seller_id)
        await sell_ticket.set_permissions(ctx.author, read_messages=True, send_messages=True)
        await sell_ticket.set_permissions(seller_role, read_messages=True, send_messages=True)
        tmbk = representTBMK(amount * 1000000)
        embed = await build(f"Sell | Coin | {tmbk}", f"**<@{ctx.author.id}> wants to sell {tmbk} Coins for ${round(amount * sell_price, 2)} USD**\nPayment Method: **{payment_method}**", 0xFFFFFF)
        await sell_ticket.send(embed=embed)
        embed = await build("Ticket Created", f"Your ticket has been created, you can find it here: https://discord.com/channels/{ctx.guild.id}/{sell_ticket.id}", 0x2FF100)
        await response.edit(embed=embed)
        message = await sell_ticket.send(f"<@{ctx.author.id}>, <@&{seller_role.id}>")
        await message.delete()
        with open("ticket_management.json", 'r+') as ticket:
            the_json['ids'][str(ctx.guild.id)][str(ctx.author.id)] += 1
            json.dump(the_json, ticket, indent=4)
        async with aiosqlite.connect("./database/database.db") as database:
            await database.execute('''
            INSERT INTO ticket (guild_id, channel_id, open_ticket_id)
            VALUES (?, ?, ?)
        ''', (ctx.guild.id, sell_ticket.id, ctx.author.id))
            
            await database.execute('''
            INSERT INTO queue (guild_id, channel_id, coins)
            VALUES (?, ?, ?)
        ''', (ctx.guild.id, sell_ticket.id, amount))
            
            
            await database.commit()
        

    except Exception as error:
        embed = await build('Exception Caught', f"{error}", 0xFF0000)
        await response.edit(embed=embed) 
# ---------- End of sell.py ----------

# ---------- Start of statistics.py ----------
import json, aiosqlite, discord, datetime, asyncio, os
from discord.ext import commands
from minecraft.info.tmbk import representTBMK

async def update_embed(bot):
    print('Statistics is a bit complicated, only attempt to use statistics if you know what you are doing / a developer')
    # while True:
    #     if not os.path.exists("./database/database.db"):
    #         return
    
    #     with open("config.json") as config:
    #         config = json.load(config)
            
    #     channel = await bot.fetch_channel(int(config['bot']['statistics']))
    #     message = await channel.fetch_message('1258832829824110703')
    #     async with aiosqlite.connect("./database/database.db") as database:
    #         async with database.execute('''SELECT coins FROM ticket WHERE guild_id = ?''', (1227804021142589512,)) as cursor:
    #             coins = await cursor.fetchall()
                
    #         async with database.execute('''SELECT coins FROM queue WHERE guild_id = ?''', (1227804021142589512,)) as cursor:
    #             queue = await cursor.fetchall()
            
    #         async with database.execute('SELECT COUNT(*) FROM vouch WHERE guild_id = ?', (1227804021142589512,)) as cursor:
    #             row_count_result = await cursor.fetchone()

    #         async with database.execute('SELECT * FROM ticket WHERE guild_id = ? AND channel_id IS NOT NULL', (1227804021142589512,))as cursor:
    #             open_tickets = await cursor.fetchall()

    #         async with database.execute('SELECT * FROM account WHERE guild_id = ?', (1227804021142589512,))as cursor:
    #             accounts_profiles = await cursor.fetchall()
                
    #     try:
    #         async with aiosqlite.connect('./database/database.db') as sqlite:
    #             async with sqlite.execute('SELECT channel_id FROM account WHERE guild_id = ?', (1227804021142589512,)) as cursor:
    #                 rows = await cursor.fetchall()
    #                 channel_ids = [str(row[0]) for row in rows]
    #                 number = 0
    #         for channel_id in channel_ids:
    #             try:
    #                 channel = await bot.fetch_channel(int(channel_id))
    #                 number += 1
    #             except Exception as error:
    #                 pass
    #     except Exception as error:
    #         pass
        
            
            
    #     # Extract the count from the result
    #     row_count = row_count_result[0] if row_count_result else 0
    #     total = 0
    #     queues = 0

    #     if coins == [] or coins is None:
    #         print('Empty List Coins = []')
    #     else: 
    #         for coin in coins:
    #             if coin[0] is not None:
    #                 total += coin[0]
    #     if queue == [] or queue is None:
    #         print('Empty List Queue = []')
    #     else:
    #         for que in queue:
    #             if que[0] is not None:
    #                 queues += que[0]
    #     tmbk = representTBMK(total*1000000)
    #     tbmk2 = representTBMK(queues*1000000)
    #     embed = discord.Embed(title='Flux QOL Statistics', description='Tracking Since <t:1720198800>', color=0x1D0FC7)
    #     embed.add_field(name=f'Total Coins Handled: {tmbk}', value=f'', inline=False)
    #     embed.add_field(name=f'Total Vouches: {row_count}', value=f'', inline=False)
    #     embed.add_field(name=f'Lifetime Created Tickets: - {len(open_tickets)}', value='', inline=False)
    #     embed.add_field(name=f'Sell Coin Queue: 0', value='', inline=False)
    #     embed.add_field(name=f'Accounts / Profiles Listed: {number}', value='', inline=False)
    #     embed.set_footer(text='Made by interceptic', icon_url='https://avatars.githubusercontent.com/u/121205983?s=400&u=e5e1ec3c308a713e198f46aff29038bc4dca1d9d&v=4')
    #     embed.timestamp = datetime.datetime.now()
    #     embed.thumbnail = "https://media.discordapp.net/attachments/1227398031112933478/1233568070782554253/fluxbanner.png?ex=6689318a&is=6687e00a&hm=86a40117bdd2b47664ef71679ba0435efd3704fec6f649aa95fff68a1687636d&=&quality=lossless"
    #     await message.edit(content=None, embed=embed)
    #     print('total')
    #     await asyncio.sleep(60*30)
    
# ---------- End of statistics.py ----------

# ---------- Start of verify.py ----------
import aiosqlite, datetime, discord, asyncio
from discord.ext import commands

async def setup_vouch(ctx):
    pass
# ---------- End of verify.py ----------

# ---------- Start of button.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
import aiosqlite
from bot.modals.views.button2 import button2
from bot.build_embed import build

def button_view(discord_int, title, label):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)
    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, int1: discord.interactions.Interaction):
                user_input = self.children[0].value
                
                
                await int1.response.defer()
                await button2(discord_int, "Account Category ID", "ID", user_input)
                

        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    return view
# ---------- End of button.py ----------

# ---------- Start of button2.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.modals.views.button3 import button3
from bot.build_embed import build


async def button2(discord_int, title, label, seller_role):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                user_input = self.children[0].value
                await interaction.response.defer()
               
                await button3(discord_int, "Profile Category ID", "ID", seller_role, user_input)
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 2/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button2.py ----------

# ---------- Start of button3.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
from bot.modals.views.button4 import button4


async def button3(discord_int, title, label, seller_role, account_cat):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)
    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                user_input = self.children[0].value
                await interaction.response.defer()
                await button4(discord_int, "Coin Price that YOU will buy for", "Price", seller_role, account_cat, user_input)
        await interaction.response.send_modal(InputModal())
    

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 3/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)
    return

# ---------- End of button3.py ----------

# ---------- Start of button4.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
from bot.modals.views.button5 import button5


async def button4(discord_int, title, label, seller_role, account_cat, profile_cat):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                user_input = self.children[0].value
                await interaction.response.defer()
               
                await button5(discord_int, "Coin Price that YOU will sell for", "Price", seller_role, account_cat, profile_cat, user_input)
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 4/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button4.py ----------

# ---------- Start of button5.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
from bot.modals.views.button6 import button6


async def button5(discord_int, title, label, seller_role, account_cat, profile_cat, buy_price):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                user_input = self.children[0].value
                await interaction.response.defer()
               
                await button6(discord_int, "Buy Tickets Category ID", "ID", seller_role, account_cat, profile_cat, buy_price, user_input)
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 5/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button5.py ----------

# ---------- Start of button6.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
from bot.modals.views.button7 import button7


async def button6(discord_int, title, label, seller_role, account_cat, profile_cat, buy_price, sell_price):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                user_input = self.children[0].value
                await interaction.response.defer()
               
                await button7(discord_int, "Sell Ticket Category ID", "ID", seller_role, account_cat, profile_cat, buy_price, sell_price, user_input)
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 6/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button6.py ----------

# ---------- Start of button7.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
from bot.modals.views.button8 import button8


async def button7(discord_int, title, label, seller_role, account_cat, profile_cat, buy_price, sell_price, ticket_cat_buy):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                user_input = self.children[0].value
                await interaction.response.defer()
               
                await button8(discord_int, "New Listing Ping Role", "ID", seller_role, account_cat, profile_cat, buy_price, sell_price, ticket_cat_buy, user_input)
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 7/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button7.py ----------

# ---------- Start of button8.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
from bot.modals.views.button9 import button9


async def button8(discord_int, title, label, seller_role, account_cat, profile_cat, buy_price, sell_price, ticket_cat_buy, ticket_cat_sell):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                user_input = self.children[0].value
                await interaction.response.defer()
               
                await button9(discord_int, "Vouch Channel ID", "ID", seller_role, account_cat, profile_cat, buy_price, sell_price, ticket_cat_buy, ticket_cat_sell, user_input)
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 8/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button8.py ----------

# ---------- Start of button9.py ----------
import discord
from discord.ui import View, Button, InputText, Modal
from bot.build_embed import build
import aiosqlite


async def button9(discord_int, title, label, seller_role, account_cat, profile_cat, buy_price, sell_price, ticket_buy, ticket_sell, ping_role):
    open_menu_button = Button(label=title, style=discord.ButtonStyle.blurple)

    async def input_text_callback(interaction):
        class InputModal(Modal):
            def __init__(self):
                super().__init__(title=title)
                self.add_item(InputText(label=label))

            async def callback(self, interaction: discord.Interaction):
                global embed
                vouch_channel = self.children[0].value
                await interaction.response.defer()
                guild_id = discord_int.guild.id
                try:
                    async with aiosqlite.connect('./database/database.db') as database:
                        await database.execute(
                            '''
                            INSERT INTO info (
                                guild_id, seller_id, category_id_account, category_id_profile, category_id_sell, coin_price_buy, coin_price_sell, ping_role, category_id_buy, vouch_channel_id 
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ''',
                            (guild_id, seller_role, account_cat, profile_cat, ticket_sell, buy_price, sell_price, ping_role, ticket_buy, vouch_channel)
                        )
                        await database.commit()
                except Exception as error:
                    embed = await build('Error Setting up database', f"{error}", 0xFF0000)
                    await discord_int.edit(embed=embed)
                    return
                embed = await build("Database Setup!", "Run the /list command again to list your account!", 0x0CFF00)
                view = View()
                await discord_int.edit(embed=embed, view=view)
                return
               
        await interaction.response.send_modal(InputModal())

    open_menu_button.callback = input_text_callback
    
    view = View()
    view.add_item(open_menu_button)
    embed = await build("Database Not Found", "Please initiate the setup process by clicking the button below \n **Step 9/9**", 0xFF0000)
    await discord_int.edit(embed=embed, view=view)

# ---------- End of button9.py ----------

# ---------- Start of sqlite.py ----------
import aiosqlite
import asyncio

async def setup_db():
    async with aiosqlite.connect('./database/database.db') as sqlite:
        await sqlite.execute('''
            CREATE TABLE IF NOT EXISTS [info] (
                [guild_id] INTEGER,
                [category_id_account] INTEGER,
                [seller_id] INTEGER,
                [category_id_profile] INTEGER,
                [category_id_sell] INTEGER,
                [coin_price_buy] FLOAT,
                [coin_price_sell] FLOAT,
                [ping_role] INTEGER,
                [category_id_buy] INTEGER,
                [vouch_channel_id] INTEGER
            )
        ''')
        await asyncio.sleep(0.3)
        await sqlite.execute('''
            CREATE TABLE IF NOT EXISTS [account] (
                [guild_id] INTEGER,
                [channel_id] INTEGER,
                [ign] STRING,
                [price] INTEGER,
                [seller_id] INTEGER,
                [offer] INTEGER,
                [channel_name] STRING
            )
        ''')
        await asyncio.sleep(0.3)
        await sqlite.execute('''
            CREATE TABLE IF NOT EXISTS [ticket] (
                [guild_id] INTEGER,
                [channel_id] INTEGER,
                [open_ticket_id] INTEGER,
                [coins] INT,
                [price] INTEGER,
                [seller_id] INTEGER
            )
        ''')
        await asyncio.sleep(0.3)
        await sqlite.execute('''
            CREATE TABLE IF NOT EXISTS [vouch] (
                [guild_id] INTEGER,
                [seller_id] INTEGER,
                [voucher_name] STRING,
                [vouch_profile_picture] STRING,
                [vouch_content] INTEGER,
                [uuid] STRING
            )
        ''')
        await asyncio.sleep(0.3)
        await sqlite.execute('''
            CREATE TABLE IF NOT EXISTS [queue] (
            [guild_id] INTEGER,
            [channel_id] INTEGER,
            [coins] INTEGER
            )
        ''')
        await asyncio.sleep(0.3)
        await sqlite.commit()
        print('Commited')
        
async def vouch_db(ctx):
    return
        
        
        


# ---------- End of sqlite.py ----------

# ---------- Start of shiyu.py ----------
import asyncio
import aiohttp
from minecraft.info.username import user_data
from bot.build_embed import build



async def shiyu_data(ctx, username):
    async with aiohttp.ClientSession() as shiyu_session:
        user = await user_data(ctx, username)
        
        try:
            async with shiyu_session.get(f'https://sky.shiiyu.moe/stats/{username}/') as abcd:
                await asyncio.sleep(3)
        except:
            pass
        
        try:    
            async with shiyu_session.get(f"https://sky.shiiyu.moe/api/v2/profile/{user['id']}") as response:
                if response.status != 200:
                    embed = await build(f"Caught Exception: {response.status}", f"**From Shiyu API: {response.reason}**", 0xFF0000)
                    await ctx.edit(embed=embed)
                    return
                username = await response.json()
                return username
        except Exception as error:
            print(f'Exception triggered: {error}')      
            return error 
# ---------- End of shiyu.py ----------

# ---------- Start of tmbk.py ----------
def representTBMK(value):
	response = value
	if value >= 1000000000000:
		response = str(round(value / 1000000000000, 1)) + "T"
	elif value >= 1000000000:
		response = str(round(value / 1000000000, 1)) + "B"
	elif value >= 1000000:
		response = str(round(value / 1000000)) + "M"
	elif value >= 1000:
		response = str(round(value / 1000, 1)) + "K"

	return response

# ---------- End of tmbk.py ----------

# ---------- Start of username.py ----------
import aiohttp
import asyncio
from bot.build_embed import build


async def user_data(ctx, username):
    async with aiohttp.ClientSession() as username_info:
        try:
            async with username_info.get(f'https://api.mojang.com/users/profiles/minecraft/{username}') as response:
                if response.status != 200:
                    print(response.status, response.reason)
                    embed = await build(f"Caught Exception: {response.status}", f"**From Mojang API: {response.reason}**", 0xFF0000)
                    await ctx.edit(embed=embed)
                    return
                return await response.json()
        except Exception as error:
            print(f"Exception triggered: {error}")
            return

# ---------- End of username.py ----------

# ---------- Start of data_handler.py ----------
from minecraft.info.shiyu import shiyu_data
statistics = {}


async def user_stats(ctx, username):
    statistics[username] = await shiyu_data(ctx, username) # calls the function to get data
    statistics[username]['names'] = [statistics[username]['profiles'][f'{profile_id}']['cute_name'] for profile_id in statistics[username]['profiles']] # returns the names of profiles
    statistics[username]['profile_ids'] = {name: profile_id for name, profile_id in zip(statistics[username]['names'], statistics[username]['profiles'])}
    return statistics

async def handle_stats(selected_profile, username):
    newDict = {} # will contain cata, skills, only important info
    location = statistics[username]['profile_ids'][selected_profile] # find where in the array is
    

    newDict = {username: {
        "level": 0,
        "cata": {
            "level": 0
        },
        "hotm": {
            "level": 0,
            "mithril_powder": 0,
            "gemstone_powder": 0,
            "glacite_powder": 0
        },
        "networth": {
            "unsoulbound": 0,
            "soulbound": 0
        },
        "skills": {
            "average": 0,
            "combat": 0,
            "fishing": 0,
            "foraging": 0,
            "mining": 0,
            "farming": 0
        },
        "slayers": {
            "zombie": 0,
            "spider": 0,
            "wolf": 0,
            "enderman": 0,
            "vampire": 0,
            "blaze": 0
        },
        "crimson": {
            "faction": "N/A",
            "mage": 0,
            "barbarian": 0
        },
        "weight": {
            "senither": 0,
            "lily": 0
        },
        "minions": {
            "total": 0,
            "bonus": 0
        }
    }
}


    try:
        newDict[username]['cata']['level'] = statistics[username]['profiles'][location]["data"]["dungeons"]["catacombs"]["level"]["level"] # cata level
    except KeyError as error:
        newDict[username]['cata']['level'] = 0
    try: 
        newDict[username]['skills']['average'] = round(statistics[username]['profiles'][location]["data"]["skills"]["averageSkillLevel"]) # average skill level
    except KeyError as error:
        pass
    try:   
        newDict[username]['hotm']['level'] = statistics[username]["profiles"][location]["data"]["mining"]["core"]["level"]["level"]
    except KeyError as error:
        pass
    try:
        newDict[username]['hotm']['mithril_powder'] = statistics[username]["profiles"][location]["data"]["mining"]["core"]["powder"]["mithril"]["total"]
    except KeyError as error:
        pass
    try:
        newDict[username]['hotm']['gemstone_powder'] = statistics[username]["profiles"][location]["data"]["mining"]["core"]["powder"]["gemstone"]["total"]
    except KeyError as error:
        pass
    try:
        newDict[username]['hotm']['glacite_powder'] = statistics[username]["profiles"][location]["data"]["mining"]["core"]["powder"]["glacite"]["total"]
    except KeyError as error:
        pass
    try:
        newDict[username]['networth']['unsoulbound'] = round(statistics[username]["profiles"][location]["data"]["networth"]["unsoulboundNetworth"])
    except KeyError as error:
        pass
    try:
        newDict[username]['networth']['soulbound'] = round(statistics[username]["profiles"][location]["data"]["networth"]["networth"]) - round(statistics[username]["profiles"][location]["data"]["networth"]["unsoulboundNetworth"])
    except KeyError as error:
        pass
    try:
        newDict[username]['skills']['combat'] = statistics[username]["profiles"][location]["data"]['skills']['skills']['combat']['level']
    except KeyError as error:
        pass
    try:
        newDict[username]['skills']['fishing'] = statistics[username]["profiles"][location]["data"]['skills']['skills']['fishing']['level']
    except KeyError as error:
        pass
    try:
        newDict[username]['skills']['foraging'] = statistics[username]["profiles"][location]["data"]['skills']['skills']['foraging']['level']
    except KeyError as error:
        pass
    try:
        newDict[username]['skills']['mining'] = statistics[username]["profiles"][location]["data"]['skills']['skills']['mining']['level']
    except KeyError as error:
        pass
    try:
        newDict[username]['skills']['farming'] = statistics[username]["profiles"][location]["data"]['skills']['skills']['farming']['level']
    except KeyError as error:
        pass
    try:
        newDict[username]['slayers']['zombie'] = statistics[username]["profiles"][location]["data"]["slayer"]["slayers"]["zombie"]["level"]["currentLevel"]
    except KeyError as error:
        pass
    try:
        newDict[username]['slayers']['spider'] = statistics[username]["profiles"][location]["data"]["slayer"]["slayers"]["spider"]["level"]["currentLevel"]
    except KeyError as error:
        pass
    try:
        newDict[username]['slayers']['wolf'] = statistics[username]["profiles"][location]["data"]["slayer"]["slayers"]["wolf"]["level"]["currentLevel"]
    except KeyError as error:
        pass
    try:
        newDict[username]['slayers']['enderman'] = statistics[username]["profiles"][location]["data"]["slayer"]["slayers"]["enderman"]["level"]["currentLevel"]
    except KeyError as error:
        pass
    try:
        newDict[username]['slayers']['vampire'] = statistics[username]["profiles"][location]["data"]["slayer"]["slayers"]["vampire"]["level"]["currentLevel"]
    except KeyError as error:
        pass
    try:
        newDict[username]['slayers']['blaze'] = statistics[username]["profiles"][location]["data"]["slayer"]["slayers"]["blaze"]["level"]["currentLevel"]
    except KeyError as error:
        pass
    try:
        newDict[username]['crimson']['mage'] = statistics[username]["profiles"][location]["data"]["crimson_isle"]["factions"]["mages_reputation"]
    except KeyError as error:
        pass
    try:
        newDict[username]['crimson']['barbarian'] = statistics[username]["profiles"][location]["data"]["crimson_isle"]["factions"]["barbarians_reputation"]
    except KeyError as error:
        pass
    try:
        newDict[username]['level'] = statistics[username]["profiles"][location]["data"]["skyblock_level"]["level"]
    except KeyError as error:
        pass
    try:
        newDict[username]['minions']['total'] = statistics[username]["profiles"][location]["data"]["minions"]["minion_slots"]["current"]
    except KeyError as error:
        pass
    try: 
        newDict[username]['minions']['bonus'] = statistics[username]["profiles"][location]["data"]["misc"]["profile_upgrades"]["minion_slots"]
    except KeyError as error:
        pass
    try:
        newDict[username]['crimson']['faction'] = statistics[username]["profiles"][location]["data"]["crimson_isle"]["factions"]["selected_faction"]
    except KeyError as error:
        pass
    try:
        newDict[username]['weight']['senither'] = round(statistics[username]["profiles"][location]["data"]["weight"]["senither"]["overall"], 0)
    except KeyError as error:
        pass     
    try:
        newDict[username]['weight']['lily'] = round(statistics[username]["profiles"][location]["data"]["weight"]["lily"]["total"], 0)
    except KeyError as error:
        pass 


    if 'MVP' in statistics[username]['profiles'][location]['data']['rank_prefix'] and 'rank-plus' in statistics[username]['profiles'][location]['data']['rank_prefix']:
        rank = 'MVP+'
    elif 'MVP' in statistics[username]['profiles'][location]['data']['rank_prefix'] and 'rank-plus' not in statistics[username]['profiles'][location]['data']['rank_prefix']:
        rank = 'MVP'
    elif 'VIP+' in statistics[username]['profiles'][location]['data']['rank_prefix'] and 'rank-plus' in statistics[username]['profiles'][location]['data']['rank_prefix']:
        rank = 'VIP+'
    elif 'VIP' in statistics[username]['profiles'][location]['data']['rank_prefix'] and 'rank-plus' not in statistics[username]['profiles'][location]['data']['rank_prefix']:
        rank = 'VIP'
    else:
        rank = 'NON'
    return newDict, rank



# ---------- End of data_handler.py ----------

# ---------- Start of price_data.py ----------
import json
from minecraft.pricing.values.catacombs import catacombs
from minecraft.pricing.values.networth import networth
from minecraft.pricing.values.hotm import hotm
from minecraft.pricing.values.skills import skills
from minecraft.pricing.values.slayers import slayers
from minecraft.pricing.values.crimson import crimson


with open("config.json") as conf:
    config = json.load(conf)


async def pricer(dict, username):
    priced_dict = {}
    priced_dict = {username: {
        "total": 0,
        "cata": {
            "level": 0
        },
        "total_hotm": 0,
        "hotm": {
            "level": 0,
            "mithril_powder": 0,
            "gemstone_powder": 0,
            "glacite_powder": 0
        },
        "total_nw": 0,
        "networth": {
            "unsoulbound": 0,
            "soulbound": 0
        },
        "total_skills": 0,
        "skills": {
            "average": 0,
            "combat": 0,
            "fishing": 0,
            "foraging": 0,
            "mining": 0,
            "farming": 0
        },
        "total_slayers": 0,
        "slayers": {
            "zombie": 0,
            "spider": 0,
            "wolf": 0,
            "enderman": 0,
            "vampire": 0,
            "blaze": 0
        },
        "total_crimson": 0,
        "crimson": {
            "mage": 0,
            "barbarian": 0
        }
    }}

    dict, priced_dict, username = await catacombs(dict, priced_dict, username)
    dict, priced_dict, username = await networth(dict, priced_dict, username)
    dict, priced_dict, username = await hotm(dict, priced_dict, username)
    dict, priced_dict, username = await skills(dict, priced_dict, username)
    dict, priced_dict, username = await slayers(dict, priced_dict, username)
    priced_dict = await crimson(dict, priced_dict, username)

    priced_dict[username]['total'] = round(priced_dict[username]['cata']['level'] + priced_dict[username]['total_hotm'] + priced_dict[username]['total_nw'] + priced_dict[username]['total_skills'] + priced_dict[username]['total_slayers'] + priced_dict[username]['total_crimson'], 2)

    a = 's'
    return priced_dict, a
# ---------- End of price_data.py ----------

# ---------- Start of catacombs.py ----------
import json

with open("config.json") as conf:
    config = json.load(conf)
async def catacombs(dict, priced_dict, username):
    for level in range(1, dict[username]['cata']['level']+1):
        if level <= 10: 
            priced_dict[username]['cata']['level'] += 0.08
        if level <= 23 & level > 10:
            priced_dict[username]['cata']['level'] += 0.12
        if level == 24:
            priced_dict[username]['cata']['level'] += 1.5 * config['advanced']['cata24']
        if level <= 32 and level > 24:
            priced_dict[username]['cata']['level'] += 0.65
        if level <= 40 and level > 32:
            priced_dict[username]['cata']['level'] += 0.90
        if level <= 45 and level > 40:
            priced_dict[username]['cata']['level'] += 1
        if level <= 49 and level > 45:
            priced_dict[username]['cata']['level'] += 2.50
        if level == 50:
            priced_dict[username]['cata']['level'] += 10
        if level >= 51:
            priced_dict[username]['cata']['level'] += 4
    priced_dict[username]["cata"]["level"] = round((priced_dict[username]["cata"]["level"] * config['pricing']['catacombs']), 2)
    return(dict, priced_dict, username)

# ---------- End of catacombs.py ----------

# ---------- Start of crimson.py ----------
import json

with open("config.json") as conf:
    config = json.load(conf)

async def crimson(dict, priced_dict, username):
    mage = round(dict[username]['crimson']['mage'] / 1000)
    barbarian = round(dict[username]['crimson']['barbarian'] / 1000)
    total = abs(round(mage - barbarian))
    total = (total * 0.83) * config['advanced']['crimson']
    priced_dict[username]['total_crimson'] = total
    return priced_dict

# ---------- End of crimson.py ----------

# ---------- Start of hotm.py ----------
import json

with open("config.json") as conf:
    config = json.load(conf)

async def hotm(dict, priced_dict, username):
    for tier in range(1, dict[username]['hotm']['level']+1):
        if tier == 1:
            priced_dict[username]['hotm']['level'] += 0.33
        if tier == 2:
            priced_dict[username]['hotm']['level'] += 0.66
        if tier == 3:
            priced_dict[username]['hotm']['level'] += 1
        if tier == 4:
            priced_dict[username]['hotm']['level'] += 1.5
        if tier == 5:
            priced_dict[username]['hotm']['level'] += 2
        if tier == 6:
            priced_dict[username]['hotm']['level'] += 3
        if tier == 7:
            priced_dict[username]['hotm']['level'] += 7 * config['advanced']['hotm7']
        if tier == 8:
            priced_dict[username]['hotm']['level'] += 5
        if tier == 9:
            priced_dict[username]['hotm']['level'] += 5
        if tier == 10:
            priced_dict[username]['hotm']['level'] += 5 * config['advanced']['hotm10']
    priced_dict[username]['hotm']['level'] = round(priced_dict[username]['hotm']['level'])  
    priced_dict[username]['hotm']['mithril_powder'] = round(dict[username]['hotm']['mithril_powder'] / 100000) * config['pricing']['mithril_powder']
    priced_dict[username]['hotm']['gemstone_powder'] = round(dict[username]['hotm']['gemstone_powder'] / 100000) * config['pricing']['gemstone_powder']
    priced_dict[username]['hotm']['glacite_powder'] = round(dict[username]['hotm']['glacite_powder'] / 100000) * config['pricing']['glacite_powder']
    priced_dict[username]['total_hotm'] =  round(priced_dict[username]['hotm']['level'] + priced_dict[username]['hotm']['mithril_powder'] + priced_dict[username]['hotm']['gemstone_powder'] + priced_dict[username]['hotm']['glacite_powder'], 2)
    
    
    
    return dict, priced_dict, username
# ---------- End of hotm.py ----------

# ---------- Start of networth.py ----------
import json

with open("config.json") as conf:
    config = json.load(conf)

async def networth(dict, priced_dict, username):
    unsoulbound = round(dict[username]['networth']['unsoulbound'] / 1000000)
    soulbound = round(dict[username]['networth']['soulbound']/1000000)
    priced_dict[username]['networth']['unsoulbound'] = round(unsoulbound * config['pricing']['networth_unsb'],2)
    priced_dict[username]['networth']['soulbound'] = round(soulbound * config['pricing']['networth_sb'],2)
    priced_dict[username]['total_nw'] = priced_dict[username]['networth']['unsoulbound'] + priced_dict[username]['networth']['soulbound']
    return dict, priced_dict, username
# ---------- End of networth.py ----------

# ---------- Start of skills.py ----------
import json

with open("config.json") as conf:
    config = json.load(conf)

async def skills(dict, priced_dict, username):
    combat = dict[username]["skills"]["combat"]
    fishing = dict[username]["skills"]["fishing"]
    foraging = dict[username]["skills"]["foraging"]
    mining = dict[username]["skills"]["mining"]
    farming = dict[username]["skills"]["farming"]
    average = dict[username]["skills"]["average"]
    
    
    for i in range(1, combat+1):
        if i <= 20:
            priced_dict[username]['skills']['combat'] += 0.04
        if i <= 40 and i > 20:
            priced_dict[username]['skills']['combat'] += 0.08
        if i <= 50 and i > 40:
            priced_dict[username]['skills']['combat'] += 0.20
        if i <= 60 and i > 50:
            priced_dict[username]['skills']['combat'] += 0.25

    for i in range(1, fishing+1):
        if i <= 20:
            priced_dict[username]['skills']['fishing'] += 0.04
        if i <= 40 and i > 20:
            priced_dict[username]['skills']['fishing'] += 0.15
        if i <= 50 and i > 40:
            priced_dict[username]['skills']['fishing'] += 0.20
        if i <= 60 and i > 50:
            priced_dict[username]['skills']['fishing'] += 0.25
    
    for i in range(1, foraging+1):
        if i <= 20:
            priced_dict[username]['skills']['foraging'] += 0.10
        if i <= 40 and i > 20:
            priced_dict[username]['skills']['foraging'] += 0.25
        if i <= 50 and i > 40:
            priced_dict[username]['skills']['foraging'] += 0.40
        if i <= 60 and i > 50:
            priced_dict[username]['skills']['foraging'] += 0.50

    for i in range(1, mining+1):
        if i <= 20:
            priced_dict[username]['skills']['mining'] += 0.04
        if i <= 40 and i > 20:
            priced_dict[username]['skills']['mining'] += 0.07
        if i <= 50 and i > 40:
            priced_dict[username]['skills']['mining'] += 0.11
        if i <= 60 and i > 50:
            priced_dict[username]['skills']['mining'] += 0.17
    
    for i in range(1, farming+1):
        if i <= 20:
            priced_dict[username]['skills']['farming'] += 0.04
        if i <= 40 and i > 20:
            priced_dict[username]['skills']['farming'] += 0.08
        if i <= 50 and i > 40:
            priced_dict[username]['skills']['farming'] += 0.20
        if i <= 60 and i > 50:
            priced_dict[username]['skills']['farming'] += 0.25
    priced_dict[username]['skills']['combat'] *= config['advanced']['combat']
    priced_dict[username]['skills']['fishing'] *= config['advanced']['fishing']
    priced_dict[username]['skills']['foraging'] *= config['advanced']['foraging']
    priced_dict[username]['skills']['mining'] *= config['advanced']['mining']
    priced_dict[username]['skills']['farming'] *= config['advanced']['farming']


    priced_dict[username]['total_skills'] = round(priced_dict[username]['skills']['farming'] + priced_dict[username]['skills']['mining'] + priced_dict[username]['skills']['foraging'] + priced_dict[username]['skills']['fishing'] + priced_dict[username]['skills']['combat'], 2)
    return dict, priced_dict, username




# ---------- End of skills.py ----------

# ---------- Start of slayers.py ----------
import json

with open("config.json") as conf:
    config = json.load(conf)

async def slayers(dict, priced_dict, username):
    for tier in range(1, dict[username]['slayers']['zombie']+1):
        if tier == 1:
            priced_dict[username]['slayers']['zombie'] += 0.03
        if tier == 2:
            priced_dict[username]['slayers']['zombie'] += 0.03
        if tier == 3:
            priced_dict[username]['slayers']['zombie'] += 0.10
        if tier == 4:
            priced_dict[username]['slayers']['zombie'] += 0.45
        if tier == 5:
            priced_dict[username]['slayers']['zombie'] += 0.75
        if tier == 6:
            priced_dict[username]['slayers']['zombie'] += 1
        if tier == 7:
            priced_dict[username]['slayers']['zombie'] += 1.5 * config['advanced']['slayer_zombie']
        if tier == 8:
            priced_dict[username]['slayers']['zombie'] += 2
        if tier == 9:
            priced_dict[username]['slayers']['zombie'] += 3
        

    for tier in range(1, dict[username]['slayers']['spider']+1):
        if tier == 1:
            priced_dict[username]['slayers']['spider'] += 0.03
        if tier == 2:
            priced_dict[username]['slayers']['spider'] += 0.03
        if tier == 3:
            priced_dict[username]['slayers']['spider'] += 0.10
        if tier == 4:
            priced_dict[username]['slayers']['spider'] += 0.45
        if tier == 5:
            priced_dict[username]['slayers']['spider'] += 0.75
        if tier == 6:
            priced_dict[username]['slayers']['spider'] += 1
        if tier == 7:
            priced_dict[username]['slayers']['spider'] += 1.5 * config['advanced']['slayer_spider']
        if tier == 8:
            priced_dict[username]['slayers']['spider'] += 2
        if tier == 9:
            priced_dict[username]['slayers']['spider'] += 3


    for tier in range(1, dict[username]['slayers']['wolf']+1):
        if tier == 1:
            priced_dict[username]['slayers']['wolf'] += 0.03
        if tier == 2:
            priced_dict[username]['slayers']['wolf'] += 0.13
        if tier == 3:
            priced_dict[username]['slayers']['wolf'] += 0.20
        if tier == 4:
            priced_dict[username]['slayers']['wolf'] += 0.50
        if tier == 5:
            priced_dict[username]['slayers']['wolf'] += 0.75
        if tier == 6:
            priced_dict[username]['slayers']['wolf'] += 1.5
        if tier == 7:
            priced_dict[username]['slayers']['wolf'] += 2 * config['advanced']['slayer_wolf']
        if tier == 8:
            priced_dict[username]['slayers']['wolf'] += 3
        if tier == 9:
            priced_dict[username]['slayers']['wolf'] += 4
   
    for tier in range(1, dict[username]['slayers']['enderman']+1):
        if tier == 1:
            priced_dict[username]['slayers']['enderman'] += 0.33
        if tier == 2:
            priced_dict[username]['slayers']['enderman'] += 0.66
        if tier == 3:
            priced_dict[username]['slayers']['enderman'] += 1
        if tier == 4:
            priced_dict[username]['slayers']['enderman'] += 1.5
        if tier == 5:
            priced_dict[username]['slayers']['enderman'] += 2
        if tier == 6:
            priced_dict[username]['slayers']['enderman'] += 3
        if tier == 7:
            priced_dict[username]['slayers']['enderman'] += 4 * config['advanced']['slayer_enderman']
        if tier == 8:
            priced_dict[username]['slayers']['enderman'] += 4
        if tier == 9:
            priced_dict[username]['slayers']['enderman'] += 5
   
    for tier in range(1, dict[username]['slayers']['vampire']+1):
        if tier == 1:
            priced_dict[username]['slayers']['vampire'] += 0.33
        if tier == 2:
            priced_dict[username]['slayers']['vampire'] += 0.66
        if tier == 3:
            priced_dict[username]['slayers']['vampire'] += 1
        if tier == 4:
            priced_dict[username]['slayers']['vampire'] += 1.5
        if tier == 5:
            priced_dict[username]['slayers']['vampire'] += 2
    

    for tier in range(1, dict[username]['slayers']['blaze']+1):
        if tier == 1:
            priced_dict[username]['slayers']['blaze'] += 0.33
        if tier == 2:
            priced_dict[username]['slayers']['blaze'] += 0.66
        if tier == 3:
            priced_dict[username]['slayers']['blaze'] += 1
        if tier == 4:
            priced_dict[username]['slayers']['blaze'] += 1.5
        if tier == 5:
            priced_dict[username]['slayers']['blaze'] += 2
        if tier == 6:
            priced_dict[username]['slayers']['blaze'] += 3
        if tier == 7:
            priced_dict[username]['slayers']['blaze'] += 4 * config['advanced']['slayer_blaze']
        if tier == 8:
            priced_dict[username]['slayers']['blaze'] += 5
        if tier == 9:
            priced_dict[username]['slayers']['blaze'] += 6
   
   
   
   
    priced_dict[username]['total_slayers'] = round((priced_dict[username]['slayers']['zombie'] + priced_dict[username]['slayers']['vampire'] + priced_dict[username]['slayers']['enderman'] + priced_dict[username]['slayers']['wolf'] + priced_dict[username]['slayers']['spider'] + priced_dict[username]['slayers']['blaze']) * config['pricing']['slayers'], 2)  

    
    
    
    return dict, priced_dict, username
# ---------- End of slayers.py ----------

